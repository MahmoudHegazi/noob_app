<?php
function ju_custom_query() {
global $wpdb;
//$user_count = $wpdb->get_var( "SELECT COUNT(*) FROM $wpdb->posts" );
//echo "<p>User count is {$user_count}</p>";


if ($_SERVER["REQUEST_METHOD"] == "POST") {

 $itemname = $_POST['item_name'];
 if (!empty($itemname)) {
  // gey the posted data
  $rdate = $_POST["request_date"];
  $rname = $_POST['item_name'];
  $rsupplier = $_POST['supplier_name'];
  $rpr = $_POST['pr'];
  $rto_buy = $_POST['amount_to_buy'];
  $raccepted = $_POST['accepted_amount'];
  $rremaning = $_POST['remaning_amount'];
  $delivered_date = $_POST['delivered_day'];
  $rnumber = $_POST['request_number'];
  $rfinal_price =   $_POST['final_price'];

  $table = $wpdb->prefix.'purchase_request';
  $data = array('request_date' => $rdate, 'item_name' => $rname,'supplier_name' => $rsupplier, 'pr' => $rpr,
  'amount_to_buy' => $rto_buy, 'accepted_amount' => $raccepted, 'remaning_amount' => $rremaning, 'delivered_day' => $delivered_date,
  'request_number' => $rnumber, 'final_price' => $rfinal_price);
  $format = array('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s');
  $wpdb->insert($table,$data,$format);
}

}
}
?>
