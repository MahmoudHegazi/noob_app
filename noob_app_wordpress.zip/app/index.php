<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php wp_head(); ?>
</head>
<body>

<div class="container">
  <!-- remove was-valid to remove the guide to required -->
  <form method="POST" class="was-validated" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
    <div class="form-group text-right">
      <label for="uname" dir="rtl">تاريخ الطلب</label>
      <input type="date" class="form-control" id="inp1" name="request_date" required>
      <div class="valid-feedback">Valid.</div>
      <div class="invalid-feedback text-left">من فضلك املاء هذا الحقل</div>
    </div>
    <div class="form-group text-right">
      <label for="uname">اسم الصنف</label>
      <input  dir="rtl" class="form-control" type="text" id="inp1" name="item_name" required>
      <div class="valid-feedback text-left">Valid.</div>
      <div class="invalid-feedback text-left">.من فضلك املاء هذا الحقل</div>
    </div>
    <div class="form-group text-right">
      <label for="uname">اسم المورد</label>
      <input class="form-control" type="text" id="inp2" name="supplier_name">
      <div class="valid-feedback text-left">Valid.</div>
      <div class="invalid-feedback text-left">.من فضلك املاء هذا الحقل</div>
    </div>

    <div class="form-group text-right">
      <label for="uname"></label>
      <input class="form-control" type="text" id="inp3" name="pr" required>
      <div class="valid-feedback text-left">Valid.</div>
      <div class="invalid-feedback text-left">.من فضلك املاء هذا الحقل</div>
    </div>



    <div class="form-group text-right">
      <label for="uname">القيمة المطلوب شراءها</label>
    <input class="form-control" type="text" id="inp4" name="amount_to_buy" required>
      <div class="valid-feedback text-left">Valid.</div>
      <div class="invalid-feedback text-left">.من فضلك املاء هذا الحقل</div>
    </div>
    <div class="form-group text-right">
      <label for="uname">القيمة المقبولة</label>
      <input class="form-control" type="text" id="inp5" name="accepted_amount">
      <div class="valid-feedback text-left">Valid.</div>
      <div class="invalid-feedback text-left">.من فضلك املاء هذا الحقل</div>
    </div>
    <div class="form-group text-right">
      <label for="uname">القيمة المتبقية</label>
      <input class="form-control" type="text" id="inp6" name="remaning_amount">
      <div class="valid-feedback text-left">Valid.</div>
      <div class="invalid-feedback text-left">.من فضلك املاء هذا الحقل</div>
    </div>
    <div class="form-group text-right">
      <label for="uname">تاريخ التسليم</label>
      <input class="form-control" type="date" id="inp7" name="delivered_day">
      <div class="valid-feedback text-left">Valid.</div>
      <div class="invalid-feedback text-left">.من فضلك املاء هذا الحقل</div>
    </div>
    <div class="form-group text-right">
      <label for="uname">رقم الطلب:</label>
      <input class="form-control" type="text" id="inp8" name="request_number" required>
      <div class="valid-feedback text-left">Valid.</div>
      <div class="invalid-feedback text-left">.من فضلك املاء هذا الحقل</div>
    </div>
    <div class="form-group text-right">
      <label for="pwd">السعر النهائي</label>
      <input class="form-control" type="text" id="inp9" name="final_price">
      <div class="valid-feedback text-left">Valid.</div>
      <div class="invalid-feedback text-left">.من فضلك املاء هذا الحقل</div>
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>
  </form>
</div>




</body>
</html>
