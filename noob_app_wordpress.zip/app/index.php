<?php 
ju_custom_query();
?>
<!doctype html>
<html>

<form method="post" action="<?php echo $_SERVER["PHP_SELF"];?>">
<input type="number" id="demo" name="user_id">
<input type="submit" value="submit">
</form>
</body>
</html>